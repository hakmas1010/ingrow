import Post from '../models/Post.js';
import User from '../models/User.js';
import { v2 as cloudinary } from 'cloudinary';

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

export const createPost = async (req, res) => {
  try {
    const { caption } = req.body;
    const image = req.file;

    if (!image) {
      return res.status(400).json({
        status: 'error',
        message: 'Please upload an image',
      });
    }

    // Upload image to Cloudinary
    const result = await cloudinary.uploader.upload(image.path, {
      folder: 'ingrow/posts',
      width: 1080,
      crop: 'scale',
    });

    // Create post
    const post = await Post.create({
      user: req.user._id,
      caption,
      image: {
        public_id: result.public_id,
        url: result.secure_url,
      },
    });

    // Populate user data
    await post.populate('user', 'username avatar');

    res.status(201).json({
      status: 'success',
      data: {
        post,
      },
    });
  } catch (error) {
    console.error('Error creating post:', error);
    res.status(500).json({
      status: 'error',
      message: 'Error creating post',
    });
  }
};

export const getFeed = async (req, res) => {
  try {
    // Get the IDs of users that the current user is following
    const user = await User.findById(req.user._id);
    const following = user.following;

    // Add current user's ID to include their own posts
    following.push(req.user._id);

    const posts = await Post.find({ user: { $in: following } })
      .populate('user', 'username avatar')
      .sort('-createdAt')
      .limit(20);

    res.status(200).json({
      status: 'success',
      results: posts.length,
      data: {
        posts,
      },
    });
  } catch (error) {
    console.error('Error fetching feed:', error);
    res.status(500).json({
      status: 'error',
      message: 'Error fetching feed',
    });
  }
};

export const likePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).json({
        status: 'error',
        message: 'Post not found',
      });
    }

    // Check if the post has already been liked
    if (post.likes.includes(req.user._id)) {
      // Unlike the post
      post.likes = post.likes.filter(
        (id) => id.toString() !== req.user._id.toString()
      );
      await post.save();

      return res.status(200).json({
        status: 'success',
        data: {
          liked: false,
          likeCount: post.likes.length,
        },
      });
    }

    // Like the post
    post.likes.push(req.user._id);
    await post.save();

    res.status(200).json({
      status: 'success',
      data: {
        liked: true,
        likeCount: post.likes.length,
      },
    });
  } catch (error) {
    console.error('Error liking post:', error);
    res.status(500).json({
      status: 'error',
      message: 'Error liking post',
    });
  }
};

export const addComment = async (req, res) => {
  try {
    const { text } = req.body;

    if (!text || !text.trim()) {
      return res.status(400).json({
        status: 'error',
        message: 'Please provide comment text',
      });
    }

    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).json({
        status: 'error',
        message: 'Post not found',
      });
    }

    // Add comment
    const comment = {
      user: req.user._id,
      text: text.trim(),
    };

    post.comments.push(comment);
    await post.save();

    // Populate user data in the comment
    await post.populate('comments.user', 'username avatar');
    const newComment = post.comments[post.comments.length - 1];

    res.status(201).json({
      status: 'success',
      data: {
        comment: newComment,
      },
    });
  } catch (error) {
    console.error('Error adding comment:', error);
    res.status(500).json({
      status: 'error',
      message: 'Error adding comment',
    });
  }
};

export const deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).json({
        status: 'error',
        message: 'Post not found',
      });
    }

    // Check if the user is the owner of the post
    if (post.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        status: 'error',
        message: 'Not authorized to delete this post',
      });
    }

    // Delete image from Cloudinary
    await cloudinary.uploader.destroy(post.image.public_id);

    // Delete post from database
    await Post.findByIdAndDelete(req.params.id);

    res.status(204).json({
      status: 'success',
      data: null,
    });
  } catch (error) {
    console.error('Error deleting post:', error);
    res.status(500).json({
      status: 'error',
      message: 'Error deleting post',
    });
  }
};
