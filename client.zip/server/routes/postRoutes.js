import express from 'express';
import * as postController from '../controllers/postController.js';
import { protect } from '../controllers/authController.js';
import multer from 'multer';

const router = express.Router();

// Configure multer for file uploads
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
      cb(null, file.fieldname + '-' + uniqueSuffix + '.' + file.mimetype.split('/')[1]);
    },
  }),
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'), false);
    }
  },
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
});

// Protect all routes after this middleware
router.use(protect);

// Post routes
router
  .route('/')
  .post(upload.single('image'), postController.createPost)
  .get(postController.getFeed);

router
  .route('/:id/like')
  .post(postController.likePost);

router
  .route('/:id/comment')
  .post(postController.addComment);

router
  .route('/:id')
  .delete(postController.deletePost);

export default router;
