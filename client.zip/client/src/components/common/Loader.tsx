import { ClipLoader } from 'react-spinners';

interface LoaderProps {
  fullScreen?: boolean;
  size?: number;
  color?: string;
}

export const Loader = ({
  fullScreen = false,
  size = 32,
  color = '#0095f6',
}: LoaderProps) => {
  const containerClass = fullScreen
    ? 'fixed inset-0 flex items-center justify-center bg-white bg-opacity-80 z-50'
    : 'flex items-center justify-center p-4';

  return (
    <div className={containerClass}>
      <ClipLoader color={color} size={size} />
    </div>
  );
};
