import { useState } from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { FiHeart, FiMessageCircle, FiBookmark, FiMoreHorizontal } from 'react-icons/fi';
import { FaHeart, FaRegComment, FaBookmark, FaRegBookmark } from 'react-icons/fa';

interface User {
  username: string;
  avatar: string;
}

interface PostProps {
  post: {
    id: string;
    user: User;
    image: string;
    caption: string;
    likes: number;
    comments: number;
    createdAt: Date;
  };
}

export const Post = ({ post }: PostProps) => {
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [showMoreOptions, setShowMoreOptions] = useState(false);
  const [comment, setComment] = useState('');
  const [likes, setLikes] = useState(post.likes);

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikes(isLiked ? likes - 1 : likes + 1);
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (comment.trim()) {
      // In a real app, this would send the comment to the server
      console.log('Comment submitted:', comment);
      setComment('');
    }
  };

  return (
    <article className="bg-white border border-border rounded-lg overflow-hidden mb-6">
      {/* Post Header */}
      <div className="flex items-center justify-between p-3 border-b border-border">
        <div className="flex items-center space-x-3">
          <Link to={`/${post.user.username}`} className="block">
            <img
              src={post.user.avatar}
              alt={post.user.username}
              className="w-8 h-8 rounded-full object-cover"
            />
          </Link>
          <Link to={`/${post.user.username}`} className="font-semibold text-sm">
            {post.user.username}
          </Link>
        </div>
        <button 
          onClick={() => setShowMoreOptions(!showMoreOptions)}
          className="text-gray-500"
        >
          <FiMoreHorizontal size={20} />
        </button>
      </div>

      {/* Post Image */}
      <div className="aspect-square bg-gray-100">
        <img
          src={post.image}
          alt={post.caption}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Post Actions */}
      <div className="p-3">
        <div className="flex justify-between mb-2">
          <div className="flex space-x-4">
            <button onClick={handleLike} className="focus:outline-none">
              {isLiked ? (
                <FaHeart className="text-red-500 w-6 h-6" />
              ) : (
                <FiHeart className="w-6 h-6" />
              )}
            </button>
            <button className="focus:outline-none">
              <FiMessageCircle className="w-6 h-6" />
            </button>
          </div>
          <button onClick={handleSave} className="focus:outline-none">
            {isSaved ? (
              <FaBookmark className="w-6 h-6" />
            ) : (
              <FaRegBookmark className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Likes */}
        <div className="font-semibold text-sm mb-1">
          {likes.toLocaleString()} likes
        </div>

        {/* Caption */}
        <div className="text-sm mb-1">
          <Link to={`/${post.user.username}`} className="font-semibold mr-2">
            {post.user.username}
          </Link>
          <span>{post.caption}</span>
        </div>

        {/* Comments */}
        {post.comments > 0 && (
          <button className="text-gray-500 text-sm mb-2">
            View all {post.comments} comments
          </button>
        )}

        {/* Timestamp */}
        <div className="text-gray-400 text-xs uppercase tracking-wider mt-2">
          {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
        </div>

        {/* Add Comment */}
        <form onSubmit={handleCommentSubmit} className="mt-3 border-t border-border pt-3">
          <div className="flex items-center">
            <input
              type="text"
              placeholder="Add a comment..."
              className="flex-1 text-sm focus:outline-none"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
            />
            <button
              type="submit"
              className={`text-primary font-semibold text-sm ${
                !comment.trim() ? 'opacity-50 cursor-default' : 'opacity-100'
              }`}
              disabled={!comment.trim()}
            >
              Post
            </button>
          </div>
        </form>
      </div>
    </article>
  );
};
