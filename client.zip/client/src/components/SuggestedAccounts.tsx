import { Link } from 'react-router-dom';

type User = {
  id: string;
  username: string;
  fullName: string;
  isVerified: boolean;
  avatar: string;
  isFollowing: boolean;
};

export const SuggestedAccounts = () => {
  // Mock data - in a real app, this would be fetched from an API
  const suggestedUsers: User[] = [
    {
      id: '1',
      username: 'johndoe',
      fullName: 'John Doe',
      isVerified: true,
      avatar: 'https://randomuser.me/api/portraits/men/1.jpg',
      isFollowing: false,
    },
    {
      id: '2',
      username: 'janesmith',
      fullName: 'Jane Smith',
      isVerified: false,
      avatar: 'https://randomuser.me/api/portraits/women/1.jpg',
      isFollowing: false,
    },
    {
      id: '3',
      username: 'traveler',
      fullName: 'Travel Enthusiast',
      isVerified: true,
      avatar: 'https://randomuser.me/api/portraits/men/2.jpg',
      isFollowing: true,
    },
  ];

  return (
    <div className="mt-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-gray-500">Suggestions For You</h3>
        <button className="text-sm font-semibold">See All</button>
      </div>

      <div className="space-y-4">
        {suggestedUsers.map((user) => (
          <div key={user.id} className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Link to={`/${user.username}`} className="block">
                <img
                  src={user.avatar}
                  alt={user.username}
                  className="w-8 h-8 rounded-full object-cover"
                />
              </Link>
              <div className="flex-1 min-w-0">
                <Link to={`/${user.username}`} className="block">
                  <p className="text-sm font-semibold truncate">{user.username}</p>
                  <p className="text-xs text-gray-500 truncate">
                    {user.isVerified && (
                      <span className="inline-flex items-center mr-1">
                        <svg
                          className="w-3 h-3 text-blue-500"
                          fill="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path d="M22.5 12.5c0-1.58-.875-2.95-2.148-3.6.154-.532.54-1.36.617-1.562.1-.31-.1-.6-.39-.6-.22 0-.54.12-.67.27-.42.42-1.125.39-1.5-.13-.47-.64-.77-1.6-.25-2.23.1-.11.14-.25.14-.39 0-.3-.24-.55-.54-.6-.83-.1-1.7.1-2.4.8-.7.7-.9 1.57-.8 2.4.05.3-.1.55-.4.6-.63.1-1.6.2-2.22.25-.52.38-.55 1.08-.13 1.5.15.13.27.45.27.67 0 .3-.3.5-.6.4-.2-.08-1.03-.46-1.56-.62C4.4 9.55 3.5 10.9 3.5 12.5c0 .53.1 1.05.3 1.5H3c-.55 0-1 .45-1 1v2c0 .55.45 1 1 1h1v1c0 1.1.9 2 2 2h1v1c0 .55.45 1 1 1h2c.55 0 1-.45 1-1v-1h8v1c0 .55.45 1 1 1h2c.55 0 1-.45 1-1v-1h1c1.1 0 2-.9 2-2v-1h1c.55 0 1-.45 1-1v-2c0-.55-.45-1-1-1h-.3c.2-.45.3-.97.3-1.5zM12 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3z" />
                        </svg>
                      </span>
                    )}
                    {user.fullName}
                  </p>
                </Link>
              </div>
            </div>
            <button
              className={`text-xs font-semibold ${
                user.isFollowing ? 'text-gray-700' : 'text-blue-500'
              }`}
            >
              {user.isFollowing ? 'Following' : 'Follow'}
            </button>
          </div>
        ))}
      </div>
      
      <div className="mt-8 text-xs text-gray-400">
        <div className="flex flex-wrap gap-2 mb-4">
          <a href="#" className="hover:underline">About</a>
          <span>•</span>
          <a href="#" className="hover:underline">Help</a>
          <span>•</span>
          <a href="#" className="hover:underline">Press</a>
          <span>•</span>
          <a href="#" className="hover:underline">API</a>
          <span>•</span>
          <a href="#" className="hover:underline">Jobs</a>
          <span>•</span>
          <a href="#" className="hover:underline">Privacy</a>
          <span>•</span>
          <a href="#" className="hover:underline">Terms</a>
          <span>•</span>
          <a href="#" className="hover:underline">Locations</a>
        </div>
        <div>
          © {new Date().getFullYear()} INGROW BY YOUR NAME
        </div>
      </div>
    </div>
  );
};
