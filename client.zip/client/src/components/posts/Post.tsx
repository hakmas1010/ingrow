import { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { FaHeart, FaRegHeart, FaRegComment, FaBookmark, FaRegBookmark, FaEllipsisH } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';

interface PostProps {
  _id: string;
  user: {
    _id: string;
    username: string;
    avatar: string;
  };
  image: string;
  caption: string;
  likes: string[];
  comments: Array<{
    _id: string;
    user: {
      _id: string;
      username: string;
      avatar: string;
    };
    text: string;
    createdAt: string;
  }>;
  createdAt: string;
  onLike: (postId: string) => Promise<void>;
  onAddComment: (postId: string, text: string) => Promise<void>;
  onDelete: (postId: string) => Promise<void>;
}

export const Post = ({
  _id,
  user,
  image,
  caption,
  likes = [],
  comments = [],
  createdAt,
  onLike,
  onAddComment,
  onDelete,
}: PostProps) => {
  const [commentText, setCommentText] = useState('');
  const [showComments, setShowComments] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const { user: currentUser } = useAuthStore();
  const [showOptions, setShowOptions] = useState(false);

  const handleLike = async () => {
    try {
      await onLike(_id);
      setIsLiked(!isLiked);
    } catch (error) {
      console.error('Error liking post:', error);
    }
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
  };

  const handleCommentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    
    try {
      await onAddComment(_id, commentText);
      setCommentText('');
    } catch (error) {
      console.error('Error adding comment:', error);
    }
  };

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      try {
        await onDelete(_id);
      } catch (error) {
        console.error('Error deleting post:', error);
      }
    }
  };

  const isPostOwner = currentUser?._id === user?._id;

  return (
    <article className="bg-white border border-gray-200 rounded-lg mb-6">
      {/* Post Header */}
      <div className="flex items-center justify-between p-3 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <Link to={`/${user?.username}`} className="block">
            <img
              src={user?.avatar || '/default-avatar.png'}
              alt={user?.username}
              className="w-8 h-8 rounded-full object-cover"
            />
          </Link>
          <Link to={`/${user?.username}`} className="font-semibold text-sm">
            {user?.username}
          </Link>
        </div>
        
        <div className="relative">
          <button 
            onClick={() => setShowOptions(!showOptions)}
            className="text-gray-500 hover:text-gray-800"
          >
            <FaEllipsisH />
          </button>
          
          {showOptions && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 border border-gray-200">
              {isPostOwner && (
                <button
                  onClick={handleDelete}
                  className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                >
                  Delete Post
                </button>
              )}
              <button className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                Report
              </button>
              <button className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                Copy Link
              </button>
              <button 
                onClick={() => setShowOptions(false)}
                className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Post Image */}
      <div className="relative aspect-square bg-gray-100">
        <img
          src={image}
          alt={caption}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Post Actions */}
      <div className="p-4">
        <div className="flex justify-between mb-2">
          <div className="flex space-x-4">
            <button 
              onClick={handleLike}
              className="focus:outline-none"
              aria-label={isLiked ? 'Unlike' : 'Like'}
            >
              {isLiked ? (
                <FaHeart className="text-red-500 w-6 h-6" />
              ) : (
                <FaRegHeart className="w-6 h-6" />
              )}
            </button>
            <button 
              onClick={() => setShowComments(!showComments)}
              className="focus:outline-none"
              aria-label="Comment"
            >
              <FaRegComment className="w-6 h-6" />
            </button>
          </div>
          <button 
            onClick={handleSave}
            className="focus:outline-none"
            aria-label={isSaved ? 'Unsave' : 'Save'}
          >
            {isSaved ? (
              <FaBookmark className="w-6 h-6" />
            ) : (
              <FaRegBookmark className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Likes */}
        <div className="font-semibold text-sm mb-1">
          {likes.length} {likes.length === 1 ? 'like' : 'likes'}
        </div>

        {/* Caption */}
        <div className="text-sm mb-1">
          <Link to={`/${user?.username}`} className="font-semibold mr-2">
            {user?.username}
          </Link>
          <span>{caption}</span>
        </div>

        {/* Comments */}
        {comments.length > 0 && (
          <button 
            onClick={() => setShowComments(!showComments)}
            className="text-gray-500 text-sm mb-1"
          >
            View all {comments.length} {comments.length === 1 ? 'comment' : 'comments'}
          </button>
        )}

        {/* Comment Form */}
        <form onSubmit={handleCommentSubmit} className="mt-3 border-t border-gray-200 pt-3">
          <div className="flex items-center">
            <input
              type="text"
              placeholder="Add a comment..."
              className="flex-1 text-sm border-none focus:ring-0 focus:outline-none"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              aria-label="Add a comment"
            />
            <button
              type="submit"
              className={`text-blue-500 font-semibold text-sm ${
                !commentText.trim() ? 'opacity-50 cursor-default' : 'opacity-100'
              }`}
              disabled={!commentText.trim()}
            >
              Post
            </button>
          </div>
        </form>

        {/* Timestamp */}
        <div className="text-gray-400 text-xs uppercase tracking-wider mt-2">
          {formatDistanceToNow(new Date(createdAt), { addSuffix: true })}
        </div>
      </div>
    </article>
  );
};
