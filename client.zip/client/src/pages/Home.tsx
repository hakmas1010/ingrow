import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FiHome, FiCompass, FiPlusSquare, FiHeart, FiUser } from 'react-icons/fi';
import { Post } from '../components/Post';
import { SuggestedAccounts } from '../components/SuggestedAccounts';
import { useAuthStore } from '../store/authStore';

export const Home = () => {
  const [posts, setPosts] = useState([]);
  const { user } = useAuthStore();

  // Mock data - in a real app, this would be fetched from an API
  useEffect(() => {
    // Fetch posts from API
    const fetchPosts = async () => {
      try {
        // const response = await axios.get('/api/posts');
        // setPosts(response.data);
        
        // Mock data
        setPosts([
          {
            id: '1',
            user: {
              username: 'johndoe',
              avatar: 'https://randomuser.me/api/portraits/men/1.jpg',
            },
            image: 'https://picsum.photos/800/800',
            caption: 'Enjoying a beautiful day! 🌞 #sunshine #happy',
            likes: 124,
            comments: 24,
            createdAt: new Date(Date.now() - 3600000 * 2), // 2 hours ago
          },
          // Add more mock posts as needed
        ]);
      } catch (error) {
        console.error('Error fetching posts:', error);
      }
    };

    fetchPosts();
  }, []);

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="w-64 border-r border-border fixed h-full p-4 hidden md:block">
        <div className="flex flex-col h-full">
          <h1 className="text-2xl font-bold mb-10 p-2">Ingrow</h1>
          
          <nav className="space-y-2 flex-1">
            <Link to="/" className="flex items-center p-2 rounded hover:bg-gray-100">
              <FiHome className="w-6 h-6 mr-4" />
              <span>Home</span>
            </Link>
            <button className="flex items-center p-2 rounded hover:bg-gray-100 w-full text-left">
              <FiCompass className="w-6 h-6 mr-4" />
              <span>Explore</span>
            </button>
            <button className="flex items-center p-2 rounded hover:bg-gray-100 w-full text-left">
              <FiPlusSquare className="w-6 h-6 mr-4" />
              <span>Create</span>
            </button>
            <button className="flex items-center p-2 rounded hover:bg-gray-100 w-full text-left">
              <FiHeart className="w-6 h-6 mr-4" />
              <span>Notifications</span>
            </button>
            <Link 
              to={`/${user?.username || 'login'}`} 
              className="flex items-center p-2 rounded hover:bg-gray-100"
            >
              <FiUser className="w-6 h-6 mr-4" />
              <span>Profile</span>
            </Link>
          </nav>
          
          <div className="mt-auto p-2">
            <button className="text-sm text-primary font-semibold">
              Log Out
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 md:ml-64 max-w-2xl mx-auto">
        <div className="py-4 px-2 md:px-0">
          {/* Stories */}
          <div className="bg-white border border-border rounded-lg p-4 mb-6 overflow-x-auto">
            <div className="flex space-x-4">
              {/* Story items would go here */}
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-yellow-400 to-pink-500 p-0.5">
                  <div className="bg-white p-0.5 rounded-full">
                    <div className="w-14 h-14 rounded-full bg-gray-200"></div>
                  </div>
                </div>
                <span className="text-xs mt-1">Your Story</span>
              </div>
            </div>
          </div>

          {/* Posts */}
          <div className="space-y-6">
            {posts.map((post) => (
              <Post key={post.id} post={post} />
            ))}
          </div>
        </div>
      </div>

      {/* Right Sidebar - Suggested Accounts */}
      <div className="hidden lg:block w-80 p-4">
        <SuggestedAccounts />
      </div>
    </div>
  );
};
