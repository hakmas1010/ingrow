import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import axios from 'axios';

interface User {
  _id: string;
  username: string;
  email: string;
  fullName: string;
  avatar: string;
  isVerified: boolean;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: { username: string; email: string; password: string; fullName: string }) => Promise<void>;
  logout: () => void;
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
}

const API_URL = 'http://localhost:5000/api/v1/auth';

export const useAuthStore = create<AuthState>(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      loading: false,
      error: null,

      login: async (email: string, password: string) => {
        try {
          set({ loading: true, error: null });
          const { data } = await axios.post(`${API_URL}/login`, { email, password });
          set({
            user: data.data.user,
            isAuthenticated: true,
            loading: false,
          });
        } catch (error: any) {
          set({
            error: error.response?.data?.message || 'An error occurred during login',
            loading: false,
          });
          throw error;
        }
      },

      register: async (userData) => {
        try {
          set({ loading: true, error: null });
          const { data } = await axios.post(`${API_URL}/signup`, userData);
          set({
            user: data.data.user,
            isAuthenticated: true,
            loading: false,
          });
        } catch (error: any) {
          set({
            error: error.response?.data?.message || 'An error occurred during registration',
            loading: false,
          });
          throw error;
        }
      },

      logout: async () => {
        try {
          await axios.get(`${API_URL}/logout`, { withCredentials: true });
        } catch (error) {
          console.error('Error during logout:', error);
        } finally {
          set({
            user: null,
            isAuthenticated: false,
          });
        }
      },

      setUser: (user: User | null) => set({ user, isAuthenticated: !!user }),
      setLoading: (loading: boolean) => set({ loading }),
      setError: (error: string | null) => set({ error }),
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);

export default useAuthStore;
